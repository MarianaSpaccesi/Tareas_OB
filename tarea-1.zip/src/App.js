import logo from './logo.svg';
import './App.css';
import ComponentList from './components/container/componentAlist';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <ComponentList />
      </header>
    </div>
  );
}

export default App;
